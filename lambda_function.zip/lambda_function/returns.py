import json
import numpy as np
import pandas as pd 
import psycopg2
import psycopg2.extras as extras
import io
from io import StringIO ,BytesIO
import os
import sys
import boto3
import csv




def lambda_handler(event, context):
    
    my_session=boto3.session.Session()
    s3=my_session.resource('s3')
    BUCKET_NAME ='lhnbucket123'
    
    username='postgres'
    password='Forget123'
    host='database-1.ctibgerv5wfi.us-east-1.rds.amazonaws.com'
    db='eCommerce'
    
    conn1=psycopg2.connect(database=db,user=username,password=password,host=host,port= '5432')
    conn1.autocommit = True
    cursor = conn1.cursor()
    
  
    response = s3.Object(BUCKET_NAME,'returns.csv').get()
    data=response['Body'].read()
    data=pd.read_csv(io.BytesIO(data),encoding='utf8')
    
    
    def execute_values(conn1, df, table):
        tuples = [tuple(x) for x in df.to_numpy()]
        cols = ','.join(list(df.columns))
        
        query = "INSERT INTO %s(%s) VALUES %%s" % (table, cols)
        cursor = conn1.cursor()
        try:
            extras.execute_values(cursor, query, tuples)
            conn1.commit()
        except (Exception, psycopg2.DatabaseError) as error:
            print("Error: %s" % error)
            conn1.rollback()
            cursor.close()
            return 1
        print("execute_values() done")
        cursor.close()
          
    execute_values(conn1, data, 'returns')
        
        

    return {
        'statusCode': 200,
        'body': json.dumps('Loaded data from S3 to PostgreSQL successfully')
    }

