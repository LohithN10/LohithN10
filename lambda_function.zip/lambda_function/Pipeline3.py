import sys
import pandas as pd
import json
import boto3
import io
import csv
from io import StringIO, BytesIO
from decimal import Decimal
my_session = boto3.session.Session()
s3_resources = my_session.resource('s3')
bucket_name = 'lhnp3bucket'
key = 'products.json'
obj = s3_resources.Object(bucket_name=bucket_name,key=key)
data=json.load(obj.get()['Body'],parse_float=Decimal)
dynamodb_resource=boto3.resource('dynamodb')
products_table=dynamodb_resource.Table('product')
for object in data:
    product_id = object['product_id']
    products_table.put_item(Item = object)

