
import pandas as pd
import json 
import boto3
import io
from decimal import Decimal

my_session = boto3.session.Session()
s3_resources = my_session.resource('s3')
bucket_name = 'lhn-capstone'
key = 'claims.json'
obj = s3_resources.Object(bucket_name=bucket_name,key=key)
data=json.load(obj.get()['Body'],parse_float=Decimal)
dynamodb_resource=boto3.resource('dynamodb')
Claims=dynamodb_resource.Table('Claims')
for object in data:
    ClaimID = object['ClaimID']
    Claims.put_item(Item = object)